# Kampung Legenda - Misteri Tiga Rumah (Godot 4.3+)

Top-down multiplayer social deduction game. No external assets: tiles, characters,
particles and all audio are generated in code.

## Run
1. Open `project.godot` in Godot **4.3 or newer** (uses TileMapLayer).
2. Press F5. Click **HOST** (works alone for testing: 1 player = practice mode, no impostor).
3. Second instance: Debug > Customize Run Instances > enable multiple, then **JOIN** 127.0.0.1.
   Over LAN use the host's IP. Port: UDP 7777. Max 8 players.
4. Host presses **PLAY** in the lobby (Dataran Kampung). 2-5 players = 1 impostor, 6-8 = 2.

Controls: WASD/arrows = move, E/Space = action. On mobile: joystick + action button.

## Files
- `scripts/network_manager.gd` (Autoload) ENet host/join, InputMap (WASD etc.)
- `scripts/audio_manager.gd`  (Autoload) procedural chime, two-tone, rumble, looping wind
- `scripts/main.gd`   world build, MultiplayerSpawner/Synchronizer, RPC game logic
- `scripts/player.gd` CharacterBody2D, capsule feet collider, 4-direction frames
- `scripts/ui.gd`     menu, lobby, HUD, joystick, minimap, mini-games, meeting, game over
- `scripts/game_data.gd` maps, tasks, clues (edit here to add content)
- `scripts/interactable.gd` clue/task/well/body markers

## Notes
- Each area has its own physics layer, so WorldBoundaryShape2D edges don't block other areas.
- Movement is client-authoritative; tasks, kills, votes and win checks are server-validated.
- Late joins during a round are rejected. Mobile export: landscape, INTERNET permission.
