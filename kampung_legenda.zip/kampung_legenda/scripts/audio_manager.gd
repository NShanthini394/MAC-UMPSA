extends Node
## Autoload "AudioManager": every sound is generated procedurally.

const RATE := 22050

var _sfx := {}
var _pool: Array[AudioStreamPlayer] = []
var _wind: AudioStreamPlayer
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.seed = 1234
	_sfx["click"] = _wav(_tone([880.0], 0.14, 0.45))
	var two := _tone([660.0], 0.12, 0.45)
	two.append_array(_tone([990.0], 0.22, 0.45))
	_sfx["check"] = _wav(two)
	_sfx["rumble"] = _wav(_rumble())
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)
	_wind = AudioStreamPlayer.new()
	_wind.stream = _wav(_wind_samples(), true)
	_wind.volume_db = -16.0
	add_child(_wind)
	_wind.play()


func play(sound: String) -> void:
	if not _sfx.has(sound):
		return
	for p in _pool:
		if not p.playing:
			p.stream = _sfx[sound]
			p.play()
			return
	_pool[0].stream = _sfx[sound]
	_pool[0].play()


func set_volume(linear: float) -> void:
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(linear, 0.0001)))


func _tone(freqs: Array, dur: float, amp: float) -> PackedFloat32Array:
	var n := int(RATE * dur)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var t := float(i) / RATE
		var env := exp(-t * 16.0) * minf(1.0, t * 300.0)
		var s := 0.0
		for f in freqs:
			s += sin(TAU * float(f) * t)
		out[i] = s / freqs.size() * env * amp
	return out


func _rumble() -> PackedFloat32Array:
	var n := int(RATE * 1.0)
	var out := PackedFloat32Array()
	out.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		y += (_rng.randf_range(-1.0, 1.0) - y) * 0.03
		out[i] = (y * 3.0 + sin(TAU * 55.0 * t) * 0.5) * exp(-t * 2.5) * 0.8
	return out


func _wind_samples() -> PackedFloat32Array:
	var n := RATE * 4
	var out := PackedFloat32Array()
	out.resize(n)
	var y := 0.0
	for i in n:
		var t := float(i) / RATE
		y += (_rng.randf_range(-1.0, 1.0) - y) * 0.08
		out[i] = y * (0.6 + 0.4 * sin(TAU * 0.5 * t)) * 1.2
	return out


func _wav(samples: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w
