extends RefCounted
## Static data: areas, walls, furniture, doors, tasks and clues.

const TILE := 48

# Tile ids in the generated atlas
const T_SAND := 0
const T_WOOD := 1
const T_WALL := 2
const T_RUG := 3
const T_PURPLE := 4
const T_GRASS := 5
const T_DOOR := 6
const T_ROOF := 7

# 0 = hub, 1..3 = houses. Each area sits far apart in the same world and has its
# own physics layer (1 << area) so boundaries/walls never affect other areas.
const AREAS := [
	{"name": "Dataran Kampung", "origin": Vector2(0, 0), "size": Vector2i(40, 24), "floor": 5},
	{"name": "Rumah Pak Kaduk", "origin": Vector2(4000, 0), "size": Vector2i(28, 17), "floor": 1},
	{"name": "Rumah Mahsuri", "origin": Vector2(8000, 0), "size": Vector2i(28, 17), "floor": 1},
	{"name": "Rumah Puteri Gunung Ledang", "origin": Vector2(12000, 0), "size": Vector2i(28, 17), "floor": 4},
]

const SPAWN_TILE := Vector2i(20, 19)
const WELL_TILE := Vector2i(20, 16)

# [Rect2i, tile]
const DECOR := {
	0: [[Rect2i(2, 8, 36, 14), 0]],
	1: [[Rect2i(8, 5, 8, 5), 3]],
	2: [[Rect2i(10, 5, 8, 6), 3]],
	3: [[Rect2i(9, 4, 10, 8), 3]],
}

# Solid tile blocks in addition to the automatic border walls: [Rect2i, tile]
const EXTRA_WALLS := {
	0: [[Rect2i(3, 2, 9, 6), 7], [Rect2i(16, 2, 9, 6), 7], [Rect2i(28, 2, 9, 6), 7]],
	2: [[Rect2i(16, 1, 1, 6), 2]],
}

# Y-sorted furniture: [Rect2i, Color, name]
const FURN := {
	0: [
		[Rect2i(19, 13, 2, 2), Color(0.62, 0.62, 0.68), "Perigi"],
		[Rect2i(5, 13, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
		[Rect2i(33, 13, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
		[Rect2i(9, 19, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
		[Rect2i(30, 19, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
		[Rect2i(13, 11, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
		[Rect2i(26, 11, 2, 2), Color(0.12, 0.38, 0.14), "Pokok"],
	],
	1: [
		[Rect2i(10, 6, 5, 3), Color(0.45, 0.28, 0.12), "Meja"],
		[Rect2i(2, 2, 3, 4), Color(0.6, 0.5, 0.3), "Katil"],
		[Rect2i(8, 1, 8, 1), Color(0.4, 0.25, 0.12), "Rak"],
		[Rect2i(22, 2, 3, 2), Color(0.2, 0.2, 0.22), "Dapur"],
		[Rect2i(21, 10, 3, 2), Color(0.5, 0.36, 0.18), "Peti"],
	],
	2: [
		[Rect2i(2, 10, 3, 4), Color(0.75, 0.35, 0.5), "Katil"],
		[Rect2i(21, 2, 4, 2), Color(0.4, 0.25, 0.12), "Meja tulis"],
		[Rect2i(8, 1, 4, 1), Color(0.35, 0.22, 0.12), "Almari"],
	],
	3: [
		[Rect2i(12, 2, 4, 2), Color(0.85, 0.7, 0.2), "Takhta"],
		[Rect2i(3, 3, 2, 2), Color(0.8, 0.65, 0.25), "Peti emas"],
		[Rect2i(22, 9, 2, 2), Color(0.35, 0.25, 0.6), "Jambangan"],
	],
}

# Door zones (auto teleport): from area/rect -> to area/spawn tile
const DOORS := [
	{"area": 0, "rect": Rect2i(6, 8, 3, 1), "to": 1, "tile": Vector2i(13, 13)},
	{"area": 0, "rect": Rect2i(19, 8, 3, 1), "to": 2, "tile": Vector2i(13, 13)},
	{"area": 0, "rect": Rect2i(31, 8, 3, 1), "to": 3, "tile": Vector2i(13, 13)},
	{"area": 1, "rect": Rect2i(12, 15, 4, 1), "to": 0, "tile": Vector2i(7, 10)},
	{"area": 2, "rect": Rect2i(12, 15, 4, 1), "to": 0, "tile": Vector2i(20, 10)},
	{"area": 3, "rect": Rect2i(12, 15, 4, 1), "to": 0, "tile": Vector2i(32, 10)},
]

# kind: find (instant) | seq (press 1..n in order) | choice (pick right answer)
const TASKS := [
	{"id": 0, "area": 1, "label": "Cari ayam yang hilang", "kind": "find", "tile": Vector2i(23, 7),
		"text": "Ayam Pak Kaduk dijumpai bersembunyi di reban!"},
	{"id": 1, "area": 1, "label": "Susun barang mengikut urutan", "kind": "seq", "n": 4, "tile": Vector2i(5, 11)},
	{"id": 2, "area": 1, "label": "Cari kesan tapak kaki", "kind": "find", "tile": Vector2i(24, 13),
		"text": "Kesan tapak kaki di belakang rumah menuju ke sungai."},
	{"id": 3, "area": 2, "label": "Cari surat lama", "kind": "find", "tile": Vector2i(22, 6),
		"text": "Surat terkoyak di dalam bilik!"},
	{"id": 4, "area": 2, "label": "Selesaikan teka-teki", "kind": "choice", "tile": Vector2i(6, 6),
		"q": "Surat lama itu berbau minyak wangi bunga. Siapakah pemiliknya?",
		"opts": ["Badang", "Mahsuri", "Pak Pandir"], "ans": 1},
	{"id": 5, "area": 2, "label": "Bandingkan tulisan dokumen", "kind": "choice", "tile": Vector2i(24, 12),
		"q": "Peta yang ditulis tergesa-gesa sepadan dengan tulisan siapa?",
		"opts": ["Pak Pandir", "Puteri", "Pak Kaduk"], "ans": 0},
	{"id": 6, "area": 3, "label": "Selesaikan teka-teki tujuh barang", "kind": "seq", "n": 7, "tile": Vector2i(13, 8)},
	{"id": 7, "area": 3, "label": "Buka laluan rahsia", "kind": "find", "tile": Vector2i(24, 5),
		"text": "Simbol bulan ditekan - laluan rahsia terbuka!"},
	{"id": 8, "area": 3, "label": "Cari artifak", "kind": "find", "tile": Vector2i(4, 12),
		"text": "Artifak persembahan yang hilang ditemui."},
]

const CLUE_SPOTS := {
	1: [Vector2i(3, 8), Vector2i(8, 12), Vector2i(18, 4), Vector2i(19, 12), Vector2i(25, 3), Vector2i(16, 13)],
	2: [Vector2i(6, 12), Vector2i(12, 8), Vector2i(19, 5), Vector2i(20, 13), Vector2i(25, 8), Vector2i(10, 3)],
	3: [Vector2i(7, 6), Vector2i(18, 7), Vector2i(25, 9), Vector2i(9, 13), Vector2i(20, 13), Vector2i(2, 8)],
}
const CLUES_PER_HOUSE := 4

const CLUES := [
	{"t": "Kotak emas", "x": "Satu daripada tujuh barang persembahan hilang. Kotak emas ini meninggalkan kesan jari.", "c": Color(0.9, 0.75, 0.2)},
	{"t": "Kain sutera", "x": "Kain sutera ini ditemui di belakang rumah. Coraknya seakan sama dengan pakaian salah seorang pemain.", "c": Color(0.45, 0.3, 0.75)},
	{"t": "Simbol bulan", "x": "Simbol ini terdapat pada pintu rahsia di bilik dalam.", "c": Color(0.9, 0.8, 0.4)},
	{"t": "Bulu ayam", "x": "Bulu ayam ini ditemui di belakang rumah. Ia bukan daripada ayam Pak Kaduk.", "c": Color(0.4, 0.3, 0.25)},
	{"t": "Kepingan kad", "x": "Kepingan kad ini tertinggal di tepi sawah. Ada kesan tanah pada permukaannya.", "c": Color(0.9, 0.9, 0.85)},
	{"t": "Kesan tapak kaki", "x": "Kesan tapak kaki ini menuju ke arah sungai. Ia tidak sepadan dengan saiz kaki orang dewasa.", "c": Color(0.5, 0.38, 0.25)},
	{"t": "Batu besar", "x": "Batu besar ini mempunyai kesan calar. Seperti ada yang cuba mengangkatnya.", "c": Color(0.5, 0.5, 0.52)},
	{"t": "Kain ikat kepala", "x": "Kain ikat kepala ini ditemui berhampiran kawasan latihan. Ada kesan peluh dan lumpur.", "c": Color(0.3, 0.4, 0.7)},
	{"t": "Gelang kayu", "x": "Gelang kayu ini bukan milik penduduk kampung. Ia mempunyai ukiran suku kaum tertentu.", "c": Color(0.55, 0.38, 0.2)},
	{"t": "Surat lama", "x": "Surat lama ini separuh koyak. Tulisan pada bahagian ini masih boleh dibaca.", "c": Color(0.9, 0.85, 0.65)},
	{"t": "Minyak wangi", "x": "Botol minyak wangi ini terdapat kesan cap jari. Baunya masih kuat sehingga kini.", "c": Color(0.85, 0.5, 0.7)},
	{"t": "Bunga asing", "x": "Bunga ini ditemui di luar rumah Mahsuri. Ia bukan bunga tempatan kampung.", "c": Color(0.95, 0.95, 0.95)},
	{"t": "Beg makanan", "x": "Beg ini berisi makanan yang tidak habis dimakan. Ada kesan kunyahan pada bungkusan.", "c": Color(0.75, 0.65, 0.45)},
	{"t": "Tempurung kelapa", "x": "Tempurung kelapa ini tertinggal di tepi jalan. Terdapat kesan tanah basah.", "c": Color(0.4, 0.25, 0.15)},
	{"t": "Peta", "x": "Peta ini menunjukkan arah yang salah. Ia seperti ditulis dengan tergesa-gesa.", "c": Color(0.85, 0.75, 0.5)},
]
