class_name Interactable
extends Node2D
## Clue / task / well / body marker. Drawn with simple shapes plus a bobbing "!".

var kind := "clue"   # task | clue | well | body
var id := 0
var area := 0
var title := ""
var text := ""
var done := false
var color := Color(0.9, 0.7, 0.2)
var _t := 0.0


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _draw() -> void:
	if kind == "body":
		draw_rect(Rect2(-26, -16, 52, 20), color.darkened(0.2))
		draw_circle(Vector2(30, -6), 11, Color(0.96, 0.8, 0.65))
		draw_string(ThemeDB.fallback_font, Vector2(-30, -30), "MAYAT", HORIZONTAL_ALIGNMENT_CENTER, 60, 16, Color(1, 0.3, 0.3))
		return
	draw_circle(Vector2(0, -6), 15, color.darkened(0.4))
	draw_circle(Vector2(0, -9), 12, color)
	var y := -64.0 + sin(_t * 4.0) * 4.0
	if done:
		draw_circle(Vector2(0, y), 15, Color(0.3, 0.8, 0.35))
		draw_string(ThemeDB.fallback_font, Vector2(-15, y + 8), "OK", HORIZONTAL_ALIGNMENT_CENTER, 30, 20, Color.WHITE)
	else:
		draw_circle(Vector2(0, y), 15, Color(1, 0.85, 0.2))
		draw_string(ThemeDB.fallback_font, Vector2(-15, y + 9), "!", HORIZONTAL_ALIGNMENT_CENTER, 30, 26, Color(0.25, 0.1, 0))
