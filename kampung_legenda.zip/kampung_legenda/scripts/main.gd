extends Node
## World + game logic. Server (peer 1) is authoritative for roles, tasks, kills, votes.
## Node tree built in code:
##   Main
##   |- Maps (TileMapLayers + StaticBody2D walls + WorldBoundaryShape2D)
##   |- Entities (y-sorted: furniture, interactables, players)
##   |- Spawner (MultiplayerSpawner -> Entities)
##   |- StateSync (MultiplayerSynchronizer: tasks_active / tasks_done)
##   |- UI (CanvasLayer)

const D = preload("res://scripts/game_data.gd")
const UIScript = preload("res://scripts/ui.gd")

enum State { MENU, LOBBY, EXPLORE, MEETING, GAME_OVER }

const MEETING_SECONDS := 30
const KILL_COOLDOWN_MS := 20000
const START_COOLDOWN_MS := 15000
const RESUME_COOLDOWN_MS := 10000
const KILL_RANGE := 120.0
const INTERACT_RANGE := 110.0

var state: int = State.MENU
var tasks_active := 0   # replicated by StateSync
var tasks_done := 0     # replicated by StateSync

var entities: Node2D
var maps: Node2D
var spawner: MultiplayerSpawner
var ui
var tileset: TileSet
var particle_tex: ImageTexture

var is_impostor := false
var fellow_imps: Array = []
var teleporting := false
var door_lock := 0.0
var meeting_left := 0.0
var kill_end_ms := 0
var emergency_used_local := false
var spawn_counter := 0
var task_nodes := {}
var well_node: Interactable
var clue_nodes: Array = []
var body_nodes := {}
var _mission_sig := ""

# server only
var roles := {}
var alive_srv := {}
var kill_ready := {}
var emergency_used := {}
var votes := {}
var initial_imps := 0
var meeting_end_ms := 0
var resolving := false


func _ready() -> void:
	add_to_group("main")
	_build_world()
	ui = UIScript.new()
	ui.name = "UI"
	add_child(ui)
	ui.setup(self)
	ui.host_pressed.connect(_on_host)
	ui.join_pressed.connect(_on_join)
	ui.play_pressed.connect(_on_play)
	ui.action_pressed.connect(_on_action)
	ui.vote_cast.connect(_on_vote_cast)
	ui.lobby_pressed.connect(_on_lobby_btn)
	ui.minigame_done.connect(_on_minigame_done)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	NetworkManager.peers_changed.connect(_on_peers_changed)
	NetworkManager.connected.connect(_enter_lobby)
	NetworkManager.connection_lost.connect(_on_connection_lost)
	ui.show_menu()


# ------------------------------------------------------------------ world build
func _build_world() -> void:
	RenderingServer.set_default_clear_color(Color(0.04, 0.06, 0.05))
	tileset = _make_tileset()
	particle_tex = _make_particle_tex()
	maps = Node2D.new()
	maps.name = "Maps"
	add_child(maps)
	entities = Node2D.new()
	entities.name = "Entities"
	entities.y_sort_enabled = true
	add_child(entities)
	for a in D.AREAS.size():
		_build_area(a)
	_build_static_interactables()

	spawner = MultiplayerSpawner.new()
	spawner.name = "Spawner"
	spawner.spawn_path = NodePath("../Entities")
	spawner.spawn_function = _spawn_fn
	add_child(spawner)

	var sync := MultiplayerSynchronizer.new()
	sync.name = "StateSync"
	var cfg := SceneReplicationConfig.new()
	for prop in [".:tasks_active", ".:tasks_done"]:
		var np := NodePath(prop)
		cfg.add_property(np)
		cfg.property_set_spawn(np, true)
		cfg.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE)
	sync.replication_config = cfg
	add_child(sync)


func _make_tileset() -> TileSet:
	var cols := [
		Color(0.85, 0.72, 0.48), Color(0.55, 0.38, 0.2), Color(0.28, 0.2, 0.14), Color(0.6, 0.2, 0.2),
		Color(0.4, 0.3, 0.55), Color(0.3, 0.55, 0.25), Color(0.9, 0.75, 0.3), Color(0.45, 0.25, 0.18),
	]
	var img := Image.create(D.TILE * cols.size(), D.TILE, false, Image.FORMAT_RGBA8)
	for t in cols.size():
		var base: Color = cols[t]
		for y in D.TILE:
			for x in D.TILE:
				var c := base
				if (floori(x / 8.0) + floori(y / 8.0)) % 2 == 0:
					c = c.darkened(0.06)
				if x == 0 or y == 0:
					c = c.darkened(0.2)
				img.set_pixel(t * D.TILE + x, y, c)
	var ts := TileSet.new()
	ts.tile_size = Vector2i(D.TILE, D.TILE)
	var src := TileSetAtlasSource.new()
	src.texture = ImageTexture.create_from_image(img)
	src.texture_region_size = Vector2i(D.TILE, D.TILE)
	for t in cols.size():
		src.create_tile(Vector2i(t, 0))
	ts.add_source(src, 0)
	return ts


func _make_particle_tex() -> ImageTexture:
	var img := Image.create(12, 12, false, Image.FORMAT_RGBA8)
	img.fill(Color(1, 1, 1, 0))
	for y in 12:
		for x in 12:
			if absi(x - 6) + absi(y - 6) <= 5:   # diamond
				img.set_pixel(x, y, Color.WHITE)
	return ImageTexture.create_from_image(img)


func _fill(layer: TileMapLayer, rect: Rect2i, tile: int) -> void:
	for y in range(rect.position.y, rect.position.y + rect.size.y):
		for x in range(rect.position.x, rect.position.x + rect.size.x):
			layer.set_cell(Vector2i(x, y), 0, Vector2i(tile, 0))


func _walls_for(a: int) -> Array:
	var sz: Vector2i = D.AREAS[a]["size"]
	var out: Array = [
		[Rect2i(0, 0, sz.x, 1), D.T_WALL], [Rect2i(0, sz.y - 1, sz.x, 1), D.T_WALL],
		[Rect2i(0, 0, 1, sz.y), D.T_WALL], [Rect2i(sz.x - 1, 0, 1, sz.y), D.T_WALL],
	]
	var extra: Array = D.EXTRA_WALLS.get(a, [])
	out.append_array(extra)
	return out


func _build_area(a: int) -> void:
	var info: Dictionary = D.AREAS[a]
	var o: Vector2 = info["origin"]
	var sz: Vector2i = info["size"]
	var layer := TileMapLayer.new()
	layer.name = "Floor%d" % a
	layer.tile_set = tileset
	layer.position = o
	maps.add_child(layer)
	_fill(layer, Rect2i(0, 0, sz.x, sz.y), info["floor"])
	var decor: Array = D.DECOR.get(a, [])
	for d in decor:
		_fill(layer, d[0], d[1])
	for dr in D.DOORS:
		if dr["area"] == a:
			_fill(layer, dr["rect"], D.T_DOOR)
	for w in _walls_for(a):
		_fill(layer, w[0], w[1])
		_add_solid(a, w[0])
	var furn: Array = D.FURN.get(a, [])
	for f in furn:
		_add_furniture(a, f)
	_add_boundaries(a)


func _add_solid(a: int, rect: Rect2i) -> void:
	var o: Vector2 = D.AREAS[a]["origin"]
	var body := StaticBody2D.new()
	body.collision_layer = 1 << a
	body.collision_mask = 0
	body.position = o + (Vector2(rect.position) + Vector2(rect.size) * 0.5) * D.TILE
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = Vector2(rect.size) * D.TILE
	cs.shape = rs
	body.add_child(cs)
	maps.add_child(body)


## WorldBoundaryShape2D half-planes keep players inside; per-area physics layers
## stop one area's boundaries from affecting the others.
func _add_boundaries(a: int) -> void:
	var o: Vector2 = D.AREAS[a]["origin"]
	var px := Vector2(D.AREAS[a]["size"]) * D.TILE
	var edges := [
		[o + Vector2(px.x * 0.5, 0), Vector2(0, 1)],
		[o + Vector2(px.x * 0.5, px.y), Vector2(0, -1)],
		[o + Vector2(0, px.y * 0.5), Vector2(1, 0)],
		[o + Vector2(px.x, px.y * 0.5), Vector2(-1, 0)],
	]
	for e in edges:
		var body := StaticBody2D.new()
		body.collision_layer = 1 << a
		body.collision_mask = 0
		body.position = e[0]
		var cs := CollisionShape2D.new()
		var ws := WorldBoundaryShape2D.new()
		ws.normal = e[1]
		ws.distance = 0.0
		cs.shape = ws
		body.add_child(cs)
		maps.add_child(body)


func _add_furniture(a: int, f: Array) -> void:
	var rect: Rect2i = f[0]
	var col: Color = f[1]
	var o: Vector2 = D.AREAS[a]["origin"]
	var w := float(rect.size.x * D.TILE)
	var h := float(rect.size.y * D.TILE)
	var body := StaticBody2D.new()
	body.collision_layer = 1 << a
	body.collision_mask = 0
	body.position = o + Vector2((rect.position.x + rect.size.x * 0.5) * D.TILE, (rect.position.y + rect.size.y) * D.TILE)
	var ch := h * 0.6
	var cs := CollisionShape2D.new()
	var rs := RectangleShape2D.new()
	rs.size = Vector2(w, ch)
	cs.shape = rs
	cs.position = Vector2(0, -ch * 0.5)
	body.add_child(cs)
	var vis := ColorRect.new()
	vis.color = col
	vis.position = Vector2(-w * 0.5, -h - 20.0)
	vis.size = Vector2(w, h + 20.0)
	vis.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(vis)
	var top := ColorRect.new()
	top.color = col.lightened(0.25)
	top.position = Vector2(-w * 0.5, -h - 20.0)
	top.size = Vector2(w, 22.0)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	body.add_child(top)
	entities.add_child(body)


func _build_static_interactables() -> void:
	for t in D.TASKS:
		var it := Interactable.new()
		it.name = "Task%d" % t["id"]
		it.kind = "task"
		it.id = t["id"]
		it.area = t["area"]
		it.title = t["label"]
		it.color = Color(0.95, 0.75, 0.25)
		it.position = _tile_to_world(t["area"], t["tile"])
		it.visible = false
		it.add_to_group("interactables")
		entities.add_child(it)
		task_nodes[t["id"]] = it
	well_node = Interactable.new()
	well_node.name = "Well"
	well_node.kind = "well"
	well_node.title = "Perigi (Mesyuarat)"
	well_node.color = Color(0.3, 0.6, 0.9)
	well_node.position = _tile_to_world(0, D.WELL_TILE)
	well_node.visible = false
	well_node.add_to_group("interactables")
	entities.add_child(well_node)


func _tile_to_world(a: int, tile: Vector2i) -> Vector2:
	var o: Vector2 = D.AREAS[a]["origin"]
	return o + (Vector2(tile) + Vector2(0.5, 0.5)) * D.TILE


# -------------------------------------------------------------- helpers for UI
func area_px(a: int) -> Dictionary:
	return {"origin": D.AREAS[a]["origin"], "px": Vector2(D.AREAS[a]["size"]) * D.TILE}


func local_player() -> Player:
	if not (multiplayer.multiplayer_peer is ENetMultiplayerPeer):
		return null
	return entities.get_node_or_null(str(multiplayer.get_unique_id())) as Player


func players() -> Array:
	var out := []
	for c in entities.get_children():
		if c is Player:
			out.append(c)
	return out


func marks(a: int) -> Array:
	var out := []
	if state != State.EXPLORE:
		return out
	for id in task_nodes:
		var it: Interactable = task_nodes[id]
		if it.area == a and it.visible and not it.done:
			out.append(it.position)
	return out


func _player(id: int) -> Player:
	return entities.get_node_or_null(str(id)) as Player


func _pname(id: int) -> String:
	var p := _player(id)
	return p.player_name if p != null else "?"


func _sender() -> int:
	var s := multiplayer.get_remote_sender_id()
	return s if s != 0 else multiplayer.get_unique_id()


func _bits(m: int) -> int:
	var n := 0
	while m > 0:
		n += m & 1
		m >>= 1
	return n


# ------------------------------------------------------------ connection flow
func _on_host() -> void:
	if NetworkManager.host() != OK:
		ui.alert("Gagal memulakan server (port 7777 digunakan?)")
		return
	_enter_lobby()
	_server_spawn(1)


func _on_join(ip: String) -> void:
	if NetworkManager.join(ip.strip_edges()) != OK:
		ui.alert("Gagal menyambung")
		return
	ui.alert("Menyambung ke %s ..." % ip)


func _on_connection_lost() -> void:
	get_tree().reload_current_scene()


func _enter_lobby() -> void:
	state = State.LOBBY
	ui.show_lobby(multiplayer.is_server())
	ui.set_count(NetworkManager.player_count())


func _on_peers_changed() -> void:
	ui.set_count(NetworkManager.player_count())


func _server_spawn(id: int) -> void:
	spawn_counter += 1
	var tile := Vector2i(15 + spawn_counter % 10, 19)
	spawner.spawn({
		"id": id,
		"name": "Pemain %d" % spawn_counter,
		"idx": spawn_counter % 8,
		"pos": _tile_to_world(0, tile),
	})


func _spawn_fn(data) -> Node:
	var p := Player.new()
	p.name = str(data["id"])
	p.player_name = data["name"]
	p.color_idx = data["idx"]
	p.position = data["pos"]
	return p


func _on_peer_connected(id: int) -> void:
	if not multiplayer.is_server():
		return
	if state != State.LOBBY:
		multiplayer.multiplayer_peer.disconnect_peer(id)   # no late joins
		return
	_server_spawn(id)


func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return
	var p := _player(id)
	if p != null:
		p.queue_free()
	roles.erase(id)
	alive_srv.erase(id)
	votes.erase(id)
	if state == State.EXPLORE or state == State.MEETING:
		if not _check_win() and state == State.MEETING and not resolving:
			if votes.size() >= _alive_count():
				_resolve_meeting()


# ----------------------------------------------------------------- frame logic
func _process(delta: float) -> void:
	if state == State.MENU:
		return
	_refresh_nodes()
	if multiplayer.is_server() and state == State.MEETING and not resolving:
		if Time.get_ticks_msec() >= meeting_end_ms:
			_resolve_meeting()
	if state == State.MEETING:
		meeting_left = maxf(0.0, meeting_left - delta)
		ui.set_meeting_timer(meeting_left)
	var me := local_player()
	if me == null:
		return
	_update_action(me)
	_update_mission(me)
	if Input.is_action_just_pressed("interact"):
		_on_action()


func _physics_process(delta: float) -> void:
	door_lock = maxf(0.0, door_lock - delta)
	if state == State.MENU or state == State.MEETING or state == State.GAME_OVER:
		return
	var me := local_player()
	if me == null or me.locked or teleporting or door_lock > 0.0:
		return
	var o: Vector2 = D.AREAS[me.area_idx]["origin"]
	for d in D.DOORS:
		if d["area"] != me.area_idx:
			continue
		var rect: Rect2i = d["rect"]
		var r := Rect2(o + Vector2(rect.position) * D.TILE, Vector2(rect.size) * D.TILE)
		if r.has_point(me.position):
			door_lock = 1.0
			_teleport_local(d["to"], d["tile"])
			return


func _refresh_nodes() -> void:
	var playing := state == State.EXPLORE or state == State.MEETING
	for id in task_nodes:
		var it: Interactable = task_nodes[id]
		var bit := 1 << int(id)
		it.visible = playing and (tasks_active & bit) != 0
		it.done = (tasks_done & bit) != 0
	well_node.visible = state == State.EXPLORE and not emergency_used_local


func _teleport_local(a: int, tile: Vector2i) -> void:
	while teleporting:
		await get_tree().process_frame
	var me := local_player()
	if me == null:
		return
	teleporting = true
	var was_locked := me.locked
	me.locked = true
	await ui.fade(1.0, 0.25)
	me.position = _tile_to_world(a, tile)
	me.area_idx = a
	me.velocity = Vector2.ZERO
	await ui.fade(0.0, 0.25)
	me.locked = was_locked
	teleporting = false


# --------------------------------------------------------------- action button
func _nearest_interactable(me: Player) -> Interactable:
	var best: Interactable = null
	var bd := INTERACT_RANGE
	for n in get_tree().get_nodes_in_group("interactables"):
		var it := n as Interactable
		if it == null or not it.visible or it.area != me.area_idx:
			continue
		if it.kind == "task" and it.done:
			continue
		if it.kind == "well" and (emergency_used_local or not me.alive):
			continue
		var d := it.position.distance_to(me.position)
		if d < bd:
			bd = d
			best = it
	return best


func _nearest_victim(me: Player) -> Player:
	var best: Player = null
	var bd := KILL_RANGE
	for p in players():
		if p == me or not p.alive or p.area_idx != me.area_idx:
			continue
		if fellow_imps.has(int(str(p.name))):
			continue
		var d: float = p.position.distance_to(me.position)
		if d < bd:
			bd = d
			best = p
	return best


func _context(me: Player) -> Dictionary:
	if state != State.EXPLORE:
		return {"type": "none", "text": "AKSI", "enabled": false}
	if me.alive:
		for id in body_nodes:
			var b: Interactable = body_nodes[id]
			if b.area == me.area_idx and b.position.distance_to(me.position) < INTERACT_RANGE:
				return {"type": "report", "text": "LAPOR", "id": id, "enabled": true}
	var cooling := Time.get_ticks_msec() < kill_end_ms
	if is_impostor and me.alive and not cooling:
		var v := _nearest_victim(me)
		if v != null:
			return {"type": "kill", "text": "HAPUS", "id": int(str(v.name)), "enabled": true}
	var it := _nearest_interactable(me)
	if it != null:
		match it.kind:
			"task":
				return {"type": "interact", "text": "TUGAS", "node": it, "enabled": true}
			"clue":
				return {"type": "interact", "text": "SIASAT", "node": it, "enabled": true}
			"well":
				return {"type": "emergency", "text": "MESYUARAT", "enabled": true}
	if is_impostor and cooling:
		return {"type": "none", "text": "%ds" % ceili((kill_end_ms - Time.get_ticks_msec()) / 1000.0), "enabled": false}
	return {"type": "none", "text": "AKSI", "enabled": false}


func _update_action(me: Player) -> void:
	var ctx := _context(me)
	ui.set_action(ctx["text"], ctx["enabled"] and not me.locked)


func _on_action() -> void:
	var me := local_player()
	if me == null or me.locked or state != State.EXPLORE:
		return
	var ctx := _context(me)
	if not ctx["enabled"]:
		return
	AudioManager.play("click")
	match ctx["type"]:
		"report":
			request_meeting.rpc_id(1, ctx["id"])
		"kill":
			request_kill.rpc_id(1, ctx["id"])
			kill_end_ms = Time.get_ticks_msec() + KILL_COOLDOWN_MS
		"emergency":
			emergency_used_local = true
			request_meeting.rpc_id(1, -1)
		"interact":
			_interact(ctx["node"])


func _interact(it: Interactable) -> void:
	_burst(it.position + Vector2(0, -40))
	if it.kind == "clue":
		ui.alert("%s: %s" % [it.title, it.text])
		ui.set_clue("%s - %s" % [it.title, it.text])
	elif it.kind == "task":
		var t: Dictionary = D.TASKS[it.id]
		if t["kind"] == "find":
			ui.alert(t["text"])
			_submit_task(it.id)
		else:
			var me := local_player()
			me.locked = true
			ui.open_minigame(t)


func _on_minigame_done(task_id: int, success: bool) -> void:
	var me := local_player()
	if me != null and state != State.MEETING:
		me.locked = false
	if success:
		_burst(me.position + Vector2(0, -40))
		_submit_task(task_id)


func _submit_task(task_id: int) -> void:
	if is_impostor:
		ui.alert("Anda Impostor - tugasan ini hanya penyamaran.")
		return
	request_task.rpc_id(1, task_id)


func _burst(pos: Vector2) -> void:
	var p := GPUParticles2D.new()
	p.texture = particle_tex
	p.amount = 18
	p.lifetime = 0.7
	p.one_shot = true
	p.explosiveness = 1.0
	p.z_index = 50
	p.position = pos
	var m := ParticleProcessMaterial.new()
	m.direction = Vector3(0, -1, 0)
	m.spread = 180.0
	m.initial_velocity_min = 80.0
	m.initial_velocity_max = 190.0
	m.gravity = Vector3(0, 160, 0)
	m.scale_min = 0.6
	m.scale_max = 1.5
	m.color = Color(1.0, 0.85, 0.3)
	p.process_material = m
	maps.add_child(p)
	p.emitting = true
	get_tree().create_timer(1.3).timeout.connect(p.queue_free)


func _update_mission(me: Player) -> void:
	var lines := []
	for t in D.TASKS:
		var bit := 1 << int(t["id"])
		if (tasks_active & bit) == 0:
			continue
		if me.area_idx != 0 and t["area"] != me.area_idx:
			continue
		lines.append({"text": t["label"], "done": (tasks_done & bit) != 0})
	var title: String = "Misi Kampung" if me.area_idx == 0 else str(D.AREAS[me.area_idx]["name"])
	var sig := "%s|%s|%d" % [title, str(lines), state]
	if sig != _mission_sig:
		_mission_sig = sig
		ui.set_mission(title, lines)
	ui.set_progress(_bits(tasks_done), _bits(tasks_active))


# ------------------------------------------------------------- start the round
func _on_play() -> void:
	request_start.rpc_id(1)


@rpc("any_peer", "call_local", "reliable")
func request_start() -> void:
	if not multiplayer.is_server() or state != State.LOBBY or _sender() != 1:
		return
	var ids: Array = []
	for p in players():
		ids.append(int(str(p.name)))
	var n := ids.size()
	if n == 0:
		return
	var imp_count := 0
	if n >= 2:
		imp_count = 1 if n < 6 else 2
	ids.shuffle()
	roles.clear()
	alive_srv.clear()
	kill_ready.clear()
	emergency_used.clear()
	votes.clear()
	resolving = false
	initial_imps = imp_count
	var imps: Array = []
	for i in n:
		var is_imp := i < imp_count
		roles[ids[i]] = is_imp
		alive_srv[ids[i]] = true
		kill_ready[ids[i]] = Time.get_ticks_msec() + START_COOLDOWN_MS
		if is_imp:
			imps.append(ids[i])
	# Difficulty: number of required tasks scales with the number of players.
	var total := clampi(3 + n, 4, D.TASKS.size())
	var pool := range(D.TASKS.size())
	pool.shuffle()
	var mask := 0
	for i in total:
		mask |= 1 << int(pool[i])
	tasks_active = mask
	tasks_done = 0
	for id in ids:
		_rpc_role.rpc_id(id, roles[id], imps if roles[id] else [])
	_rpc_begin.rpc(randi(), mask)


@rpc("authority", "call_local", "reliable")
func _rpc_role(imp: bool, mates: Array) -> void:
	is_impostor = imp
	fellow_imps = mates


@rpc("authority", "call_local", "reliable")
func _rpc_begin(seed_value: int, active_mask: int) -> void:
	state = State.EXPLORE
	tasks_active = active_mask
	tasks_done = 0
	emergency_used_local = false
	kill_end_ms = Time.get_ticks_msec() + START_COOLDOWN_MS
	_clear_round_nodes()
	_spawn_clues(seed_value)
	for p in players():
		p.alive = true
		var pid := int(str(p.name))
		p.set_name_color(Color(1, 0.35, 0.35) if (is_impostor and fellow_imps.has(pid)) else Color.WHITE)
	var me := local_player()
	if me != null:
		me.locked = false
	var role_text := "IMPOSTOR" if is_impostor else "PENDUDUK"
	ui.show_game(role_text, is_impostor)
	ui.alert("Anda: %s. %s" % [role_text, "Hapuskan penduduk tanpa ditangkap!" if is_impostor else "Siapkan misi & cari Impostor!"])
	AudioManager.play("check")
	_teleport_local(0, D.SPAWN_TILE)


func _clear_round_nodes() -> void:
	for n in clue_nodes:
		if is_instance_valid(n):
			n.queue_free()
	clue_nodes.clear()
	for id in body_nodes:
		if is_instance_valid(body_nodes[id]):
			body_nodes[id].queue_free()
	body_nodes.clear()


## Clues are placed dynamically but identically on every peer from a shared seed.
func _spawn_clues(seed_value: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value
	var pool: Array = D.CLUES.duplicate()
	_shuffle(pool, rng)
	var k := 0
	for a in [1, 2, 3]:
		var spots: Array = D.CLUE_SPOTS[a].duplicate()
		_shuffle(spots, rng)
		for i in D.CLUES_PER_HOUSE:
			var c: Dictionary = pool[k % pool.size()]
			k += 1
			var it := Interactable.new()
			it.name = "Clue_%d_%d" % [a, i]
			it.kind = "clue"
			it.area = a
			it.title = c["t"]
			it.text = c["x"]
			it.color = c["c"]
			it.position = _tile_to_world(a, spots[i])
			it.add_to_group("interactables")
			entities.add_child(it)
			clue_nodes.append(it)


func _shuffle(arr: Array, rng: RandomNumberGenerator) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp


# ------------------------------------------------------------------ tasks
@rpc("any_peer", "call_local", "reliable")
func request_task(task_id: int) -> void:
	if not multiplayer.is_server() or state != State.EXPLORE:
		return
	var s := _sender()
	if roles.get(s, true):
		return
	if task_id < 0 or task_id >= D.TASKS.size():
		return
	var bit := 1 << task_id
	if (tasks_active & bit) == 0 or (tasks_done & bit) != 0:
		return
	var t: Dictionary = D.TASKS[task_id]
	var p := _player(s)
	if p == null or p.area_idx != t["area"]:
		return
	if p.position.distance_to(_tile_to_world(t["area"], t["tile"])) > INTERACT_RANGE * 2.0:
		return
	tasks_done |= bit
	_rpc_task_fx.rpc(task_id, tasks_done)
	_check_win()


@rpc("authority", "call_local", "reliable")
func _rpc_task_fx(task_id: int, done_mask: int) -> void:
	tasks_done = done_mask
	AudioManager.play("check")
	ui.alert("Misi selesai: %s" % D.TASKS[task_id]["label"])


# ------------------------------------------------------------------ killing
@rpc("any_peer", "call_local", "reliable")
func request_kill(victim: int) -> void:
	if not multiplayer.is_server() or state != State.EXPLORE:
		return
	var s := _sender()
	if not roles.get(s, false) or not alive_srv.get(s, false):
		return
	if roles.get(victim, true) or not alive_srv.get(victim, false):
		return
	if Time.get_ticks_msec() < int(kill_ready.get(s, 0)):
		return
	var k := _player(s)
	var v := _player(victim)
	if k == null or v == null or k.area_idx != v.area_idx:
		return
	if k.position.distance_to(v.position) > KILL_RANGE * 1.6:
		return
	alive_srv[victim] = false
	kill_ready[s] = Time.get_ticks_msec() + KILL_COOLDOWN_MS
	_rpc_kill.rpc(s, victim, v.position, v.area_idx)
	_check_win()


@rpc("authority", "call_local", "reliable")
func _rpc_kill(killer: int, victim: int, pos: Vector2, a: int) -> void:
	var p := _player(victim)
	if p != null:
		p.alive = false
	var b := Interactable.new()
	b.name = "Body%d" % victim
	b.kind = "body"
	b.id = victim
	b.area = a
	b.position = pos
	if p != null:
		b.color = Player.COLORS[p.color_idx % Player.COLORS.size()]
	entities.add_child(b)
	body_nodes[victim] = b
	AudioManager.play("rumble")
	var me := local_player()
	var my_id := multiplayer.get_unique_id()
	if me != null and (my_id == victim or my_id == killer or me.area_idx == a):
		me.shake = 24.0
		ui.vignette()


# ------------------------------------------------------------------ meeting
@rpc("any_peer", "call_local", "reliable")
func request_meeting(body_id: int) -> void:
	if not multiplayer.is_server() or state != State.EXPLORE:
		return
	var s := _sender()
	if not alive_srv.get(s, false):
		return
	var reason := ""
	if body_id >= 0:
		if alive_srv.get(body_id, true):
			return
		reason = "%s melaporkan mayat %s." % [_pname(s), _pname(body_id)]
	else:
		if emergency_used.get(s, false):
			return
		emergency_used[s] = true
		reason = "%s memanggil mesyuarat di perigi." % _pname(s)
	votes.clear()
	resolving = false
	meeting_end_ms = Time.get_ticks_msec() + MEETING_SECONDS * 1000
	state = State.MEETING
	_rpc_meeting.rpc(reason, MEETING_SECONDS)


@rpc("authority", "call_local", "reliable")
func _rpc_meeting(reason: String, secs: int) -> void:
	state = State.MEETING
	meeting_left = float(secs)
	var me := local_player()
	if me != null:
		me.locked = true
	for id in body_nodes:
		if is_instance_valid(body_nodes[id]):
			body_nodes[id].queue_free()
	body_nodes.clear()
	var plist := []
	for p in players():
		plist.append({"id": int(str(p.name)), "name": p.player_name, "alive": p.alive,
			"color": Player.COLORS[p.color_idx % Player.COLORS.size()]})
	plist.sort_custom(func(x, y): return x["id"] < y["id"])
	var total := _bits(tasks_active)
	var left := total - _bits(tasks_done)
	ui.show_meeting(reason, float(secs), plist, me != null and me.alive, left, total)
	AudioManager.play("click")
	_goto_meeting(plist)


func _goto_meeting(plist: Array) -> void:
	while teleporting:
		await get_tree().process_frame
	var me := local_player()
	if me == null:
		return
	teleporting = true
	await ui.fade(1.0, 0.3)
	var idx := 0
	for i in plist.size():
		if plist[i]["id"] == multiplayer.get_unique_id():
			idx = i
	var center := Vector2(20, 14) * D.TILE   # well centre
	var ang := TAU * float(idx) / float(maxi(plist.size(), 1))
	me.position = center + Vector2.from_angle(ang) * 190.0
	me.area_idx = 0
	me.velocity = Vector2.ZERO
	await ui.fade(0.0, 0.3)
	teleporting = false


func _on_vote_cast(target: int) -> void:
	request_vote.rpc_id(1, target)


@rpc("any_peer", "call_local", "reliable")
func request_vote(target: int) -> void:
	if not multiplayer.is_server() or state != State.MEETING or resolving:
		return
	var s := _sender()
	if not alive_srv.get(s, false) or votes.has(s):
		return
	if target != -1 and not alive_srv.get(target, false):
		return
	votes[s] = target
	_rpc_vote_progress.rpc(votes.size(), _alive_count())
	if votes.size() >= _alive_count():
		_resolve_meeting()


@rpc("authority", "call_local", "reliable")
func _rpc_vote_progress(n: int, total: int) -> void:
	ui.set_meeting_status("Undian diterima: %d / %d" % [n, total])


func _alive_count() -> int:
	var n := 0
	for id in alive_srv:
		if alive_srv[id]:
			n += 1
	return n


func _resolve_meeting() -> void:
	if state != State.MEETING or resolving:
		return
	resolving = true
	var tally := {}
	for v in votes.values():
		tally[v] = int(tally.get(v, 0)) + 1
	var best := -1
	var best_n := 0
	var tie := false
	for k in tally:
		if k == -1:
			continue
		if tally[k] > best_n:
			best = k
			best_n = tally[k]
			tie = false
		elif tally[k] == best_n:
			tie = true
	if tie or int(tally.get(-1, 0)) >= best_n:
		best = -1
	var was_imp: bool = best != -1 and bool(roles.get(best, false))
	if best != -1:
		alive_srv[best] = false
	_rpc_vote_result.rpc(best, was_imp)
	await get_tree().create_timer(5.0).timeout
	resolving = false
	if state != State.MEETING:
		return
	if _check_win():
		return
	for id in kill_ready:
		kill_ready[id] = Time.get_ticks_msec() + RESUME_COOLDOWN_MS
	_rpc_resume.rpc()


@rpc("authority", "call_local", "reliable")
func _rpc_vote_result(ejected: int, was_imp: bool) -> void:
	var text := "Tiada siapa disingkirkan."
	if ejected != -1:
		var p := _player(ejected)
		if p != null:
			p.alive = false
		text = "%s disingkirkan - %s." % [_pname(ejected), "dia ADALAH Impostor!" if was_imp else "dia BUKAN Impostor"]
		if was_imp:
			AudioManager.play("check")
		else:
			AudioManager.play("rumble")   # wrong vote
			var me := local_player()
			if me != null:
				me.shake = 16.0
			ui.vignette()
	ui.show_vote_result(text)


@rpc("authority", "call_local", "reliable")
func _rpc_resume() -> void:
	state = State.EXPLORE
	kill_end_ms = Time.get_ticks_msec() + RESUME_COOLDOWN_MS
	ui.hide_meeting()
	var me := local_player()
	if me != null:
		me.locked = false


# ------------------------------------------------------------------ game over
func _check_win() -> bool:
	if state == State.GAME_OVER or state == State.LOBBY:
		return false
	var imp := 0
	var vil := 0
	for id in alive_srv:
		if alive_srv[id]:
			if roles.get(id, false):
				imp += 1
			else:
				vil += 1
	var text := ""
	if tasks_active != 0 and tasks_done == tasks_active:
		text = "PENDUDUK MENANG! Semua misi selesai."
	elif initial_imps > 0 and imp == 0:
		text = "PENDUDUK MENANG! Impostor telah disingkirkan."
	elif imp > 0 and imp >= vil:
		text = "IMPOSTOR MENANG! Kampung dikuasai."
	elif vil == 0 and imp == 0:
		text = "Permainan tamat."
	if text == "":
		return false
	state = State.GAME_OVER
	var imps: Array = []
	for id in roles:
		if roles[id]:
			imps.append(id)
	_rpc_game_over.rpc(text, imps)
	return true


@rpc("authority", "call_local", "reliable")
func _rpc_game_over(text: String, imps: Array) -> void:
	state = State.GAME_OVER
	var me := local_player()
	if me != null:
		me.locked = true
	var names := []
	for id in imps:
		names.append(_pname(id))
	ui.hide_meeting()
	ui.show_game_over(text, "Impostor: %s" % (", ".join(names) if names.size() > 0 else "tiada"), multiplayer.is_server())
	AudioManager.play("rumble" if text.begins_with("IMPOSTOR") else "check")


func _on_lobby_btn() -> void:
	request_lobby.rpc_id(1)


@rpc("any_peer", "call_local", "reliable")
func request_lobby() -> void:
	if not multiplayer.is_server() or _sender() != 1 or state != State.GAME_OVER:
		return
	roles.clear()
	alive_srv.clear()
	votes.clear()
	resolving = false
	_rpc_lobby.rpc()


@rpc("authority", "call_local", "reliable")
func _rpc_lobby() -> void:
	state = State.LOBBY
	tasks_active = 0
	tasks_done = 0
	is_impostor = false
	fellow_imps = []
	_clear_round_nodes()
	for p in players():
		p.alive = true
		p.set_name_color(Color.WHITE)
	var me := local_player()
	if me != null:
		me.locked = false
	ui.show_lobby(multiplayer.is_server())
	_teleport_local(0, D.SPAWN_TILE)
