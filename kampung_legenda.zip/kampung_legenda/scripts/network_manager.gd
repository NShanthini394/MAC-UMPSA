extends Node
## Autoload "NetworkManager": ENet connection handling + InputMap setup.

signal peers_changed
signal connected
signal connection_lost

const PORT := 7777
const MAX_PLAYERS := 8


func _ready() -> void:
	_setup_input_map()
	multiplayer.peer_connected.connect(_on_peers_changed)
	multiplayer.peer_disconnected.connect(_on_peers_changed)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_lost)
	multiplayer.server_disconnected.connect(_on_lost)


func host() -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS - 1)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	peers_changed.emit()
	return OK


func join(ip: String) -> Error:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	return OK


func player_count() -> int:
	if not (multiplayer.multiplayer_peer is ENetMultiplayerPeer):
		return 0
	return multiplayer.get_peers().size() + 1


func _on_peers_changed(_id: int) -> void:
	peers_changed.emit()


func _on_connected() -> void:
	connected.emit()
	peers_changed.emit()


func _on_lost() -> void:
	multiplayer.multiplayer_peer = null
	connection_lost.emit()


## WASD / arrows / E are mapped to the same actions the virtual joystick drives.
func _setup_input_map() -> void:
	var map := {
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"move_up": [KEY_W, KEY_UP],
		"move_down": [KEY_S, KEY_DOWN],
		"interact": [KEY_E, KEY_SPACE],
	}
	for action in map:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
		for k in map[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)
