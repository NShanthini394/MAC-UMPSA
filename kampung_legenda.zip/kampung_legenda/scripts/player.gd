class_name Player
extends CharacterBody2D
## Top-down capsule character. Origin = feet. Authority = the owning peer.

const D = preload("res://scripts/game_data.gd")

const SPEED := 200.0
const ACCEL := 20000.0     # very high: reaches full speed instantly
const FRICTION := 20000.0  # very high: stops instantly on release
const COLORS := [
	Color(0.9, 0.35, 0.3), Color(0.3, 0.6, 0.9), Color(0.35, 0.75, 0.4), Color(0.9, 0.75, 0.25),
	Color(0.7, 0.4, 0.85), Color(0.95, 0.55, 0.2), Color(0.3, 0.8, 0.8), Color(0.9, 0.5, 0.7),
]

var player_name := ""
var color_idx := 0
var facing := 1: set = _set_facing       # 0 up, 1 down, 2 left, 3 right (replicated)
var moving := false: set = _set_moving   # replicated
var area_idx := 0: set = _set_area       # replicated
var alive := true: set = _set_alive
var locked := false
var shake := 0.0
var camera: Camera2D

var _anim_t := 0.0
var _label: Label


func _init() -> void:
	add_to_group("players")
	collision_layer = 0
	collision_mask = 1
	motion_mode = MOTION_MODE_FLOATING
	# Small capsule at the feet.
	var cs := CollisionShape2D.new()
	var cap := CapsuleShape2D.new()
	cap.radius = 12.0
	cap.height = 30.0
	cs.shape = cap
	cs.rotation = PI / 2.0
	cs.position = Vector2(0, -12)
	add_child(cs)
	_label = Label.new()
	_label.position = Vector2(-70, -98)
	_label.size = Vector2(140, 26)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.add_theme_font_size_override("font_size", 18)
	_label.add_theme_color_override("font_outline_color", Color.BLACK)
	_label.add_theme_constant_override("outline_size", 6)
	add_child(_label)
	# State replication
	var sync := MultiplayerSynchronizer.new()
	sync.name = "Sync"
	var cfg := SceneReplicationConfig.new()
	for prop in [".:position", ".:facing", ".:moving", ".:area_idx"]:
		var np := NodePath(prop)
		cfg.add_property(np)
		cfg.property_set_spawn(np, true)
		cfg.property_set_replication_mode(np, SceneReplicationConfig.REPLICATION_MODE_ON_CHANGE)
	sync.replication_config = cfg
	add_child(sync)


func _enter_tree() -> void:
	set_multiplayer_authority(str(name).to_int())


func _ready() -> void:
	_label.text = player_name
	if is_multiplayer_authority():
		camera = Camera2D.new()
		add_child(camera)
		camera.make_current()
		_apply_camera()


func set_name_color(c: Color) -> void:
	_label.add_theme_color_override("font_color", c)


func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	var dir := Vector2.ZERO
	if not locked:
		dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if dir != Vector2.ZERO:
		velocity = velocity.move_toward(dir * SPEED, ACCEL * delta)
		if absf(dir.x) > absf(dir.y):
			facing = 3 if dir.x > 0.0 else 2
		else:
			facing = 1 if dir.y > 0.0 else 0
	else:
		velocity = velocity.move_toward(Vector2.ZERO, FRICTION * delta)
	moving = velocity.length() > 5.0
	move_and_slide()


func _process(delta: float) -> void:
	if moving:
		_anim_t += delta
		queue_redraw()
	if camera != null:
		if shake > 0.0:
			camera.offset = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake
			shake = move_toward(shake, 0.0, 40.0 * delta)
		else:
			camera.offset = Vector2.ZERO
	# Ghosts are only visible to other ghosts (and yourself).
	if is_multiplayer_authority() or alive:
		visible = true
	else:
		var me := get_parent().get_node_or_null(str(multiplayer.get_unique_id())) as Player
		visible = me != null and not me.alive


func _apply_camera() -> void:
	if camera == null:
		return
	var info: Dictionary = D.AREAS[area_idx]
	var o: Vector2 = info["origin"]
	var px := Vector2(info["size"]) * D.TILE
	if area_idx == 0:
		camera.limit_left = int(o.x)
		camera.limit_top = int(o.y)
		camera.limit_right = int(o.x + px.x)
		camera.limit_bottom = int(o.y + px.y)
	else:
		var c := o + px * 0.5   # houses: fixed, centred view
		camera.limit_left = int(c.x - 960.0)
		camera.limit_right = int(c.x + 960.0)
		camera.limit_top = int(c.y - 540.0)
		camera.limit_bottom = int(c.y + 540.0)
	camera.position = Vector2(0, -40)


func _set_facing(v: int) -> void:
	facing = v
	queue_redraw()


func _set_moving(v: bool) -> void:
	moving = v
	queue_redraw()


func _set_area(v: int) -> void:
	area_idx = v
	collision_mask = 1 << v
	_apply_camera()


func _set_alive(v: bool) -> void:
	alive = v
	modulate.a = 1.0 if v else 0.45


func _draw() -> void:
	var col: Color = COLORS[color_idx % COLORS.size()]
	var swing := 0.0
	if moving:
		swing = signf(sin(_anim_t * 12.0)) * 5.0   # 2-frame walk cycle
	# shadow
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 20.0, Color(0, 0, 0, 0.3))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# feet
	draw_rect(Rect2(-11 + swing, -9, 9, 9), col.darkened(0.5))
	draw_rect(Rect2(2 - swing, -9, 9, 9), col.darkened(0.5))
	# body capsule
	draw_rect(Rect2(-14, -46, 28, 38), col)
	draw_circle(Vector2(0, -46), 14.0, col)
	# head with 4-direction face
	var skin := Color(0.96, 0.8, 0.65)
	var hair := Color(0.15, 0.1, 0.08)
	draw_circle(Vector2(0, -57), 13.0, skin)
	match facing:
		0:
			draw_circle(Vector2(0, -59), 12.0, hair)
		1:
			draw_circle(Vector2(-5, -56), 2.2, Color.BLACK)
			draw_circle(Vector2(5, -56), 2.2, Color.BLACK)
			draw_rect(Rect2(-12, -70, 24, 6), hair)
		2:
			draw_circle(Vector2(-6, -56), 2.2, Color.BLACK)
			draw_rect(Rect2(-2, -70, 14, 14), hair)
		3:
			draw_circle(Vector2(6, -56), 2.2, Color.BLACK)
			draw_rect(Rect2(-12, -70, 14, 14), hair)
