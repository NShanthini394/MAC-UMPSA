extends CanvasLayer
## All UI is built in code. Coordinates are in the 1920x1080 canvas.

signal host_pressed
signal join_pressed(ip: String)
signal play_pressed
signal action_pressed
signal vote_cast(target: int)
signal lobby_pressed
signal minigame_done(task_id: int, success: bool)

const GOLD := Color(0.95, 0.78, 0.35)
const DARK := Color(0.05, 0.13, 0.17, 0.92)

var main
var root: Control
var menu: Control
var topbar: Control
var lobby_hud: Control
var game_hud: Control
var controls: Control
var joystick: Joystick
var action_btn: ActionButton
var minimap: MiniMap
var ip_edit: LineEdit
var count_label: Label
var play_btn: Button
var wait_label: Label
var role_label: Label
var mission_title: Label
var mission_list: VBoxContainer
var clue_label: Label
var progress: ProgressBar
var progress_label: Label
var alert_panel: PanelContainer
var alert_label: Label
var alert_tween: Tween
var fade_rect: ColorRect
var vignette_rect: TextureRect
var mini_panel: PanelContainer
var mini_box: VBoxContainer
var settings_panel: PanelContainer
var howto_panel: PanelContainer
var meeting_panel: PanelContainer
var meet_reason: Label
var meet_timer: Label
var meet_tasks: Label
var meet_bar: ProgressBar
var meet_grid: GridContainer
var meet_status: Label
var skip_btn: Button
var over_panel: PanelContainer
var over_title: Label
var over_detail: Label
var over_btn: Button
var over_wait: Label
var _vig_tween: Tween


func setup(main_ref) -> void:
	main = main_ref
	layer = 5
	var theme := Theme.new()
	theme.default_font_size = 28
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = theme
	add_child(root)
	_build_menu()
	_build_controls()
	_build_lobby_hud()
	_build_game_hud()
	_build_topbar()
	_build_overlays()
	_build_fx()


# ---------------------------------------------------------------- helpers
func _box(bg: Color, border: Color, bw: int, radius: int) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(14)
	return sb


func _button(parent: Node, text: String, pos: Vector2, sz: Vector2, font := 30, bg := Color(0.1, 0.25, 0.3, 0.95)) -> Button:
	var b := Button.new()
	b.text = text
	b.position = pos
	b.size = sz
	b.add_theme_font_size_override("font_size", font)
	b.add_theme_stylebox_override("normal", _box(bg, GOLD, 3, 16))
	b.add_theme_stylebox_override("hover", _box(bg.lightened(0.15), GOLD, 3, 16))
	b.add_theme_stylebox_override("pressed", _box(bg.darkened(0.2), GOLD, 3, 16))
	b.add_theme_stylebox_override("disabled", _box(Color(0.25, 0.25, 0.25, 0.9), Color(0.5, 0.5, 0.5), 3, 16))
	b.pressed.connect(AudioManager.play.bind("click"))
	parent.add_child(b)
	return b


func _label(parent: Node, text: String, pos: Vector2, sz: Vector2, font := 28, color := Color.WHITE, center := false) -> Label:
	var l := Label.new()
	l.text = text
	l.position = pos
	l.size = sz
	l.add_theme_font_size_override("font_size", font)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 6 if font > 40 else 3)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l


func _panel(parent: Node, pos: Vector2, sz: Vector2) -> PanelContainer:
	var p := PanelContainer.new()
	p.position = pos
	p.custom_minimum_size = sz
	p.size = sz
	p.add_theme_stylebox_override("panel", _box(DARK, GOLD, 3, 18))
	parent.add_child(p)
	return p


func _full(c: Control) -> void:
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE


# ---------------------------------------------------------------- menu
func _build_menu() -> void:
	menu = Control.new()
	_full(menu)
	menu.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(menu)
	var bg := ColorRect.new()
	bg.color = Color(0.12, 0.3, 0.3)
	_full(bg)
	menu.add_child(bg)
	var hill := ColorRect.new()
	hill.color = Color(0.17, 0.4, 0.22)
	hill.position = Vector2(0, 720)
	hill.size = Vector2(1920, 360)
	hill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.add_child(hill)
	_label(menu, "Kampung Legenda", Vector2(0, 110), Vector2(1920, 150), 124, GOLD, true)
	_label(menu, "Misteri Tiga Rumah", Vector2(0, 270), Vector2(1920, 60), 46, Color.WHITE, true)
	var host := _button(menu, "HOST (Pelayan)", Vector2(710, 430), Vector2(500, 90), 36, Color(0.85, 0.5, 0.1))
	host.pressed.connect(func(): host_pressed.emit())
	ip_edit = LineEdit.new()
	ip_edit.text = "127.0.0.1"
	ip_edit.position = Vector2(710, 545)
	ip_edit.size = Vector2(330, 80)
	ip_edit.add_theme_font_size_override("font_size", 32)
	menu.add_child(ip_edit)
	var join := _button(menu, "JOIN", Vector2(1055, 545), Vector2(155, 80), 32)
	join.pressed.connect(func(): join_pressed.emit(ip_edit.text))
	var st := _button(menu, "Tetapan", Vector2(710, 660), Vector2(240, 80), 30)
	st.pressed.connect(func(): settings_panel.visible = true)
	var hp := _button(menu, "Cara Bermain", Vector2(970, 660), Vector2(240, 80), 28)
	hp.pressed.connect(func(): howto_panel.visible = true)


# ---------------------------------------------------------------- controls
func _build_controls() -> void:
	controls = Control.new()
	_full(controls)
	root.add_child(controls)
	joystick = Joystick.new()
	joystick.position = Vector2(40, 680)
	joystick.size = Vector2(360, 360)
	controls.add_child(joystick)
	minimap = MiniMap.new()
	minimap.main = main
	minimap.position = Vector2(1640, 800)
	minimap.size = Vector2(250, 250)
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	controls.add_child(minimap)
	action_btn = ActionButton.new()   # overlaps the mini-map (bottom right)
	action_btn.position = Vector2(1690, 870)
	action_btn.size = Vector2(190, 190)
	action_btn.pressed.connect(func(): action_pressed.emit())
	controls.add_child(action_btn)
	controls.visible = false


func set_action(text: String, enabled: bool) -> void:
	if action_btn.label != text or action_btn.enabled != enabled:
		action_btn.label = text
		action_btn.enabled = enabled
		action_btn.queue_redraw()


# ---------------------------------------------------------------- lobby HUD
func _build_lobby_hud() -> void:
	lobby_hud = Control.new()
	_full(lobby_hud)
	root.add_child(lobby_hud)
	var badge := _panel(lobby_hud, Vector2(790, 18), Vector2(340, 70))
	count_label = Label.new()
	count_label.text = "Pemain 0/8"
	count_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	count_label.add_theme_font_size_override("font_size", 34)
	badge.add_child(count_label)
	play_btn = _button(lobby_hud, "PLAY", Vector2(420, 900), Vector2(330, 120), 56, Color(0.9, 0.55, 0.1))
	play_btn.pressed.connect(func(): play_pressed.emit())
	wait_label = _label(lobby_hud, "Menunggu host memulakan...", Vector2(420, 930), Vector2(600, 60), 32, GOLD)
	var hp := _button(lobby_hud, "How to Play", Vector2(780, 900), Vector2(300, 120), 32)
	hp.pressed.connect(func(): howto_panel.visible = true)
	lobby_hud.visible = false


func set_count(n: int) -> void:
	count_label.text = "Pemain %d/8" % n


# ---------------------------------------------------------------- game HUD
func _build_game_hud() -> void:
	game_hud = Control.new()
	_full(game_hud)
	root.add_child(game_hud)
	var p := _panel(game_hud, Vector2(1490, 20), Vector2(410, 100))
	var v := VBoxContainer.new()
	p.add_child(v)
	mission_title = Label.new()
	mission_title.text = "Misi"
	mission_title.add_theme_font_size_override("font_size", 30)
	mission_title.add_theme_color_override("font_color", GOLD)
	v.add_child(mission_title)
	mission_list = VBoxContainer.new()
	v.add_child(mission_list)
	v.add_child(HSeparator.new())
	var ct := Label.new()
	ct.text = "Clue"
	ct.add_theme_font_size_override("font_size", 26)
	ct.add_theme_color_override("font_color", GOLD)
	v.add_child(ct)
	clue_label = Label.new()
	clue_label.text = "Belum ada petunjuk."
	clue_label.custom_minimum_size = Vector2(370, 0)
	clue_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	clue_label.add_theme_font_size_override("font_size", 22)
	v.add_child(clue_label)
	progress = ProgressBar.new()
	progress.position = Vector2(640, 24)
	progress.size = Vector2(640, 34)
	progress.show_percentage = false
	game_hud.add_child(progress)
	progress_label = _label(game_hud, "Tugasan: 0/0", Vector2(640, 60), Vector2(640, 40), 26, Color.WHITE, true)
	role_label = _label(game_hud, "", Vector2(24, 96), Vector2(400, 50), 34, Color.WHITE)
	game_hud.visible = false


func set_mission(title: String, lines: Array) -> void:
	mission_title.text = "Misi - " + title
	for c in mission_list.get_children():
		c.queue_free()
	for l in lines:
		var lab := Label.new()
		lab.text = ("[x] " if l["done"] else "[  ] ") + str(l["text"])
		lab.add_theme_font_size_override("font_size", 23)
		lab.add_theme_color_override("font_color", Color(0.5, 1.0, 0.55) if l["done"] else Color.WHITE)
		mission_list.add_child(lab)


func set_clue(text: String) -> void:
	clue_label.text = text


func set_progress(done: int, total: int) -> void:
	progress.max_value = maxi(total, 1)
	progress.value = done
	progress_label.text = "Tugasan kampung: %d/%d" % [done, total]


# ---------------------------------------------------------------- top bar
func _build_topbar() -> void:
	topbar = Control.new()
	_full(topbar)
	root.add_child(topbar)
	var st := _button(topbar, "Tetapan", Vector2(20, 20), Vector2(190, 64), 26)
	st.pressed.connect(func(): settings_panel.visible = true)
	var hp := _button(topbar, "?", Vector2(220, 20), Vector2(64, 64), 30)
	hp.pressed.connect(func(): howto_panel.visible = true)
	topbar.visible = false


# ---------------------------------------------------------------- overlays
func _build_overlays() -> void:
	# alert pop-up
	alert_panel = _panel(root, Vector2(460, 125), Vector2(1000, 80))
	alert_label = Label.new()
	alert_label.custom_minimum_size = Vector2(960, 0)
	alert_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	alert_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	alert_label.add_theme_font_size_override("font_size", 30)
	alert_panel.add_child(alert_label)
	alert_panel.visible = false
	alert_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE

	# mini-game
	mini_panel = _panel(root, Vector2(460, 200), Vector2(1000, 640))
	mini_box = VBoxContainer.new()
	mini_box.add_theme_constant_override("separation", 18)
	mini_panel.add_child(mini_box)
	mini_panel.visible = false

	# settings
	settings_panel = _panel(root, Vector2(660, 300), Vector2(600, 330))
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 20)
	settings_panel.add_child(sv)
	var stl := Label.new()
	stl.text = "Tetapan"
	stl.add_theme_font_size_override("font_size", 40)
	stl.add_theme_color_override("font_color", GOLD)
	sv.add_child(stl)
	var vl := Label.new()
	vl.text = "Kelantangan"
	sv.add_child(vl)
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = 0.8
	sl.custom_minimum_size = Vector2(520, 40)
	sl.value_changed.connect(func(v: float): AudioManager.set_volume(v))
	sv.add_child(sl)
	var sc := Button.new()
	sc.text = "Tutup"
	sc.pressed.connect(func(): settings_panel.visible = false)
	sv.add_child(sc)
	settings_panel.visible = false
	AudioManager.set_volume(0.8)

	# how to play
	howto_panel = _panel(root, Vector2(360, 160), Vector2(1200, 700))
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 14)
	howto_panel.add_child(hv)
	var ht := Label.new()
	ht.text = "Cara Bermain"
	ht.add_theme_font_size_override("font_size", 44)
	ht.add_theme_color_override("font_color", GOLD)
	hv.add_child(ht)
	var hl := Label.new()
	hl.custom_minimum_size = Vector2(1140, 0)
	hl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hl.add_theme_font_size_override("font_size", 28)
	hl.text = "- Gerakkan watak dengan joystick (WASD / anak panah di PC).\n- Masuk ke rumah Pak Kaduk, Mahsuri dan Puteri Gunung Ledang melalui pintu.\n- Tekan butang AKSI (E di PC) untuk menyiasat petunjuk (!) dan menyiapkan misi.\n- Penduduk menang jika semua misi siap atau Impostor diundi keluar.\n- Impostor boleh HAPUS pemain di dalam rumah (ada tempoh rehat).\n- LAPOR mayat, atau tekan MESYUARAT di perigi, untuk Mesyuarat & Undian di Dataran Kampung.\n- Pemain yang tersingkir menjadi hantu: masih boleh bergerak dan menyiapkan misi."
	hv.add_child(hl)
	var hc := Button.new()
	hc.text = "Tutup"
	hc.pressed.connect(func(): howto_panel.visible = false)
	hv.add_child(hc)
	howto_panel.visible = false

	# meeting
	meeting_panel = _panel(root, Vector2(260, 60), Vector2(1400, 940))
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 12)
	meeting_panel.add_child(mv)
	var mt := Label.new()
	mt.text = "Mesyuarat - Dataran Kampung"
	mt.add_theme_font_size_override("font_size", 46)
	mt.add_theme_color_override("font_color", GOLD)
	mv.add_child(mt)
	meet_reason = Label.new()
	mv.add_child(meet_reason)
	meet_timer = Label.new()
	mv.add_child(meet_timer)
	meet_tasks = Label.new()
	mv.add_child(meet_tasks)
	meet_bar = ProgressBar.new()
	meet_bar.custom_minimum_size = Vector2(1300, 30)
	meet_bar.show_percentage = false
	mv.add_child(meet_bar)
	meet_grid = GridContainer.new()
	meet_grid.columns = 2
	meet_grid.add_theme_constant_override("h_separation", 20)
	meet_grid.add_theme_constant_override("v_separation", 12)
	mv.add_child(meet_grid)
	skip_btn = Button.new()
	skip_btn.text = "Langkau undi"
	skip_btn.custom_minimum_size = Vector2(0, 70)
	skip_btn.pressed.connect(_vote.bind(-1))
	mv.add_child(skip_btn)
	meet_status = Label.new()
	meet_status.add_theme_color_override("font_color", GOLD)
	mv.add_child(meet_status)
	meeting_panel.visible = false

	# game over
	over_panel = _panel(root, Vector2(560, 260), Vector2(800, 520))
	var ov := VBoxContainer.new()
	ov.add_theme_constant_override("separation", 24)
	over_panel.add_child(ov)
	over_title = Label.new()
	over_title.add_theme_font_size_override("font_size", 46)
	over_title.add_theme_color_override("font_color", GOLD)
	over_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	over_title.custom_minimum_size = Vector2(740, 0)
	over_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ov.add_child(over_title)
	over_detail = Label.new()
	over_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ov.add_child(over_detail)
	over_btn = Button.new()
	over_btn.text = "Kembali ke Lobi"
	over_btn.custom_minimum_size = Vector2(0, 90)
	over_btn.pressed.connect(func(): lobby_pressed.emit())
	ov.add_child(over_btn)
	over_wait = Label.new()
	over_wait.text = "Menunggu host..."
	over_wait.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ov.add_child(over_wait)
	over_panel.visible = false


func _build_fx() -> void:
	vignette_rect = TextureRect.new()
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.45, 1.0])
	g.colors = PackedColorArray([Color(1, 0, 0, 0), Color(0.7, 0, 0, 0.9)])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = Vector2(0.5, 0.5)
	gt.fill_to = Vector2(1.0, 0.5)
	gt.width = 256
	gt.height = 144
	vignette_rect.texture = gt
	vignette_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	vignette_rect.stretch_mode = TextureRect.STRETCH_SCALE
	_full(vignette_rect)
	vignette_rect.modulate.a = 0.0
	root.add_child(vignette_rect)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0, 0, 0, 0)
	_full(fade_rect)
	root.add_child(fade_rect)


# ---------------------------------------------------------------- visibility
func show_menu() -> void:
	menu.visible = true
	controls.visible = false
	lobby_hud.visible = false
	game_hud.visible = false
	topbar.visible = false


func show_lobby(is_host: bool) -> void:
	menu.visible = false
	controls.visible = true
	topbar.visible = true
	lobby_hud.visible = true
	game_hud.visible = false
	play_btn.visible = is_host
	wait_label.visible = not is_host
	over_panel.visible = false
	meeting_panel.visible = false
	mini_panel.visible = false
	role_label.text = ""


func show_game(role_text: String, impostor: bool) -> void:
	lobby_hud.visible = false
	game_hud.visible = true
	over_panel.visible = false
	meeting_panel.visible = false
	role_label.text = "Anda: " + role_text
	role_label.add_theme_color_override("font_color", Color(1, 0.35, 0.35) if impostor else Color(0.5, 1, 0.6))
	clue_label.text = "Belum ada petunjuk."


func alert(text: String) -> void:
	alert_label.text = text
	alert_panel.size = Vector2(1000, 80)
	alert_panel.visible = true
	alert_panel.modulate.a = 1.0
	if alert_tween != null:
		alert_tween.kill()
	alert_tween = create_tween()
	alert_tween.tween_interval(3.2)
	alert_tween.tween_property(alert_panel, "modulate:a", 0.0, 0.5)
	alert_tween.tween_callback(func(): alert_panel.visible = false)


func fade(a: float, d: float) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "color:a", a, d)
	await tw.finished


func vignette() -> void:
	if _vig_tween != null:
		_vig_tween.kill()
	vignette_rect.modulate.a = 1.0
	_vig_tween = create_tween()
	_vig_tween.tween_property(vignette_rect, "modulate:a", 0.0, 1.4)


# ---------------------------------------------------------------- mini-games
func open_minigame(t: Dictionary) -> void:
	for c in mini_box.get_children():
		c.queue_free()
	mini_panel.visible = true
	var title := Label.new()
	title.text = t["label"]
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", GOLD)
	mini_box.add_child(title)
	var info := Label.new()
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(940, 0)
	mini_box.add_child(info)
	if t["kind"] == "seq":
		var n: int = t["n"]
		info.text = "Tekan nombor mengikut urutan 1 hingga %d." % n
		var grid := GridContainer.new()
		grid.columns = 4
		grid.add_theme_constant_override("h_separation", 16)
		grid.add_theme_constant_override("v_separation", 16)
		mini_box.add_child(grid)
		var order := range(1, n + 1)
		order.shuffle()
		var st := {"next": 1, "n": n, "buttons": [], "info": info, "id": t["id"]}
		for v in order:
			var b := Button.new()
			b.text = str(v)
			b.custom_minimum_size = Vector2(200, 110)
			b.add_theme_font_size_override("font_size", 44)
			b.pressed.connect(_seq_pressed.bind(b, int(v), st))
			grid.add_child(b)
			st["buttons"].append(b)
	else:
		info.text = t["q"]
		var opts: Array = t["opts"]
		for i in opts.size():
			var b := Button.new()
			b.text = str(opts[i])
			b.custom_minimum_size = Vector2(0, 90)
			b.pressed.connect(_choice_pressed.bind(i, t, info))
			mini_box.add_child(b)
	var cancel := Button.new()
	cancel.text = "Batal"
	cancel.pressed.connect(_close_mini.bind(t["id"], false))
	mini_box.add_child(cancel)


func _seq_pressed(b: Button, v: int, st: Dictionary) -> void:
	AudioManager.play("click")
	if v == st["next"]:
		b.disabled = true
		st["next"] += 1
		if st["next"] > st["n"]:
			_close_mini(st["id"], true)
	else:
		st["next"] = 1
		for bb in st["buttons"]:
			bb.disabled = false
		st["info"].text = "Salah! Mulakan semula dari 1 hingga %d." % st["n"]


func _choice_pressed(i: int, t: Dictionary, info: Label) -> void:
	AudioManager.play("click")
	if i == int(t["ans"]):
		_close_mini(t["id"], true)
	else:
		info.text = "Jawapan salah. Cuba lagi!\n" + str(t["q"])


func _close_mini(task_id: int, ok: bool) -> void:
	mini_panel.visible = false
	minigame_done.emit(task_id, ok)


# ---------------------------------------------------------------- meeting
func show_meeting(reason: String, secs: float, plist: Array, can_vote: bool, left: int, total: int) -> void:
	meeting_panel.visible = true
	mini_panel.visible = false
	meet_reason.text = reason
	set_meeting_timer(secs)
	meet_tasks.text = "Papan skor kampung - tugasan tinggal: %d / %d" % [left, total]
	meet_bar.max_value = maxi(total, 1)
	meet_bar.value = total - left
	meet_status.text = "Undi untuk menyingkirkan Impostor." if can_vote else "Anda tersingkir - tidak boleh mengundi."
	for c in meet_grid.get_children():
		c.queue_free()
	for p in plist:
		var b := Button.new()
		b.text = str(p["name"]) + ("" if p["alive"] else " (tersingkir)")
		b.custom_minimum_size = Vector2(640, 80)
		b.disabled = not (p["alive"] and can_vote)
		b.add_theme_color_override("font_color", p["color"])
		b.pressed.connect(_vote.bind(int(p["id"])))
		meet_grid.add_child(b)
	skip_btn.disabled = not can_vote


func _vote(target: int) -> void:
	AudioManager.play("click")
	vote_cast.emit(target)
	for b in meet_grid.get_children():
		b.disabled = true
	skip_btn.disabled = true
	meet_status.text = "Undian anda dihantar."


func set_meeting_timer(left: float) -> void:
	meet_timer.text = "Masa undi: %d s" % ceili(left)


func set_meeting_status(text: String) -> void:
	meet_status.text = text


func show_vote_result(text: String) -> void:
	for b in meet_grid.get_children():
		b.disabled = true
	skip_btn.disabled = true
	meet_status.text = text
	meet_status.add_theme_font_size_override("font_size", 36)


func hide_meeting() -> void:
	meeting_panel.visible = false
	meet_status.remove_theme_font_size_override("font_size")


func show_game_over(text: String, detail: String, is_host: bool) -> void:
	over_panel.visible = true
	over_title.text = text
	over_detail.text = detail
	over_btn.visible = is_host
	over_wait.visible = not is_host


# ======================================================== custom controls
class Joystick extends Control:
	const RADIUS := 110.0
	var finger := -1
	var vec := Vector2.ZERO
	var knob := Vector2.ZERO

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventScreenTouch:
			if e.pressed and finger == -1:
				finger = e.index
				_update(e.position)
			elif not e.pressed and e.index == finger:
				_release()
		elif e is InputEventScreenDrag:
			if e.index == finger:
				_update(e.position)
		elif e is InputEventMouseButton:
			# real mouse only (touch-emulated mouse events are ignored: touch handled above)
			if e.device == InputEvent.DEVICE_ID_EMULATION or e.button_index != MOUSE_BUTTON_LEFT:
				return
			if e.pressed:
				finger = -2
				_update(e.position)
			elif finger == -2:
				_release()
		elif e is InputEventMouseMotion:
			if finger == -2 and e.device != InputEvent.DEVICE_ID_EMULATION:
				_update(e.position)

	func _update(p: Vector2) -> void:
		var d := p - size * 0.5
		if d.length() > RADIUS:
			d = d.normalized() * RADIUS
		knob = d
		vec = d / RADIUS
		if vec.length() < 0.15:
			vec = Vector2.ZERO
		_apply()
		queue_redraw()

	func _release() -> void:
		finger = -1
		vec = Vector2.ZERO
		knob = Vector2.ZERO
		_apply()
		queue_redraw()

	# The joystick drives the same InputMap actions as WASD.
	func _apply() -> void:
		_press("move_right", maxf(vec.x, 0.0))
		_press("move_left", maxf(-vec.x, 0.0))
		_press("move_down", maxf(vec.y, 0.0))
		_press("move_up", maxf(-vec.y, 0.0))

	func _press(action: String, strength: float) -> void:
		if strength > 0.01:
			Input.action_press(action, strength)
		else:
			Input.action_release(action)

	func _draw() -> void:
		var c := size * 0.5
		draw_circle(c, RADIUS, Color(1, 1, 1, 0.12))
		draw_arc(c, RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 4.0)
		draw_circle(c + knob, 48.0, Color(1, 1, 1, 0.45))
		draw_arc(c + knob, 48.0, 0.0, TAU, 32, Color(1, 1, 1, 0.8), 3.0)


class ActionButton extends Control:
	signal pressed
	var label := "AKSI"
	var enabled := false

	func _gui_input(e: InputEvent) -> void:
		var hit := false
		if e is InputEventScreenTouch and e.pressed:
			hit = true
		elif e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
			if e.device != InputEvent.DEVICE_ID_EMULATION:
				hit = true
		if hit and enabled:
			pressed.emit()

	func _draw() -> void:
		var c := size * 0.5
		var col := Color(0.95, 0.6, 0.12, 0.95) if enabled else Color(0.4, 0.4, 0.4, 0.8)
		draw_circle(c, 84.0, col.darkened(0.35))
		draw_circle(c, 76.0, col)
		draw_arc(c, 84.0, 0.0, TAU, 48, Color(1, 1, 1, 0.8), 4.0)
		draw_string(ThemeDB.fallback_font, Vector2(0, c.y + 10), label, HORIZONTAL_ALIGNMENT_CENTER, size.x, 28, Color.WHITE)


class MiniMap extends Control:
	var main

	func _process(_d: float) -> void:
		if visible:
			queue_redraw()

	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.05, 0.12, 0.15, 0.85))
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.95, 0.78, 0.35), false, 3.0)
		if main == null:
			return
		var me = main.local_player()
		if me == null:
			return
		var info: Dictionary = main.area_px(me.area_idx)
		var px: Vector2 = info["px"]
		var o: Vector2 = info["origin"]
		var sc := minf((size.x - 24.0) / px.x, (size.y - 24.0) / px.y)
		var off := (size - px * sc) * 0.5
		draw_rect(Rect2(off, px * sc), Color(0.2, 0.32, 0.3, 0.9))
		for m in main.marks(me.area_idx):
			draw_circle(off + (m - o) * sc, 4.0, Color(1, 0.85, 0.2))
		for p in main.players():
			if p.area_idx == me.area_idx and p.visible:
				var col := Color.YELLOW if p == me else Color.WHITE
				draw_circle(off + (p.position - o) * sc, 5.0, col)
